const mongoose=require('mongoose')
const Complain=require('../model/complainmodel')
const CreateComplain = async(req,res)=>{
    const complain1 = new Complain({
        userID: req.body.userID,
        mechanicID : req.body.mechanicID,
        serviceID: req.body.serviceID,
        cost: req.body.cost,
        isCompleted: req.body.isCompleted,
    })
    console.log('Complain1',complain1)
    complain1.save()
    .then(()=>{(
        res.send({
            msg:'Data Added Successfully',
            isSuccess :true
        })
    )}
)

.catch(()=>{
    res.send({
        msg:'Error',
        isSuccess: false
    })
})
}

const getComplain = async(req,res)=>{
    try{
        const getComplain=await complainmodel.find()
        console.log(getComplain)
        if(getComplain.length==0){
            return res.send({
                msg: 'No Complain Found'
            })
        }
        res.send({
            msg:'Complain Fetch Successfully',
            data:getComplain
        })
    }
    catch(error){
        console.log("Error", error)
    }
}

const deleteComplain = async(req,res)=>{
    try{
        const ID= req.params.id;
        console.log("ID", ID)
        if (!ID){
            return res.send({msg:'No Complain Found'})
        }
        const deleteComplain=await complain.findByIdAndDelete(ID)
        if(!deleteComplain){
            return res.send({msg:'No Complain Found'})
        }
        console.log(deleteComplain)
            res.send({
                msg: 'Complain Deleted Successfully',
                data: deleteComplain
            })
        }
    catch(error){
        console.log("Error", error)
    }
}

const updateComplain = async(req,res)=>{
    try{
        const ID= req.params.id;
        const {userID , serviceID , mechanicID , cost , isCompleted }=req.body;
        const ComplainDetails ={userID: userID, serviceID: serviceID, mechanicID: mechanicID, cost: cost, isCompleted:true}
        console.log("ID", ID)
        console.log("complainDetails",ComplainDetails)
        if (!ID){
            return res.send({msg:'No Complain Found'})
        }
        const updateComplain = await complain.findByIdAndUpdate(ID,UserDetails,{new:true});
        if(!updateComplain){
            return res.send({msg: "No Complain Found"})
        }
        console.log(updateComplain)
        res.send({
            msg:"Complain Updated Successfully",
            data: updateComplain
        })
    }
    catch(error){
        console.log("Error", error)
    }
}

module.exports={CreateComplain, getComplain, deleteComplain, updateComplain}