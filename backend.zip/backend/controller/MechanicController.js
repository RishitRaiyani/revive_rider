const mongoose=require('mongoose')

const nodemailer = require('nodemailer');

const sendEmail = async (req, res) => {
    try {
        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user:"rishitraiyani12345@gmail.com",
                pass:"yqtjjsnkafhgqzge"
            }
        });
        const mailOptions = {
            from: 'rishitraiyani12345@gmail.com',
            to: Mechanic.emailID,
            subject: 'Sending Email using Node.js',
            text: 'Hello , You have A Registered successfully!'
        };
        const info = await transporter.sendMail(mailOptions);
    console.log("Email sent: " + info.response);

    res.send({ message: "Email sent successfully!" });
         } 
    catch (error) 
        {
        console.error("Error sending email:", error);
        res.send({ error: "Failed to send email" });
        }
    };

const User=require('../model/mechanicmodel')
const CreateUser = async(req,res)=>{
    const user1 = new User({
        name: req.body.name,
        number: req.body.number,
        password: req.body.password,
        emailID: req.body.emailID
    })
    console.log('User1',user1)
    user1.save()
    .then(()=>{(
        res.send({
            msg:'Data Added Successfully',
            isSuccess :true
        })
    )}
)

.catch(()=>{
    res.send({
        msg:'Error',
        isSuccess: false
    })
})
}

const getUser = async(req,res)=>{
    try{
        const getUser=await usermodel.find()
        console.log(getUser)
        if(getUser.length=0){
            return res.send({
                msg: 'No User Found'
            })
        }
        res.send({
            msg:'User Fetch Successfully',
            data:getUser
        })
    }
    catch(error){
        console.log("Error", error)
    }
}

const deleteUser = async(req,res)=>{
    try{
        const ID= req.params.id;
        console.log("ID", ID)
        if (!ID){
            return res.send({msg:'No User Found'})
        }
        const deleteUser=await user.findByIdAndDelete(ID)
        if(!deleteUser){
            return res.send({msg:'No User Found'})
        }
        console.log(deleteUser)
            res.send({
                msg: 'User Deleted Successfully',
                data: deleteUser
            })
        }
    catch(error){
        console.log("Error", error)
    }
}

const updateUser = async(req,res)=>{
    try{
        const ID= req.params.id;
        const {name , number , password , emailID}=req.body;
        const UserDetails ={name: name, number: number, password: password, emailID: emailID}
        console.log("ID", ID)
        console.log("userDetails",UserDetails)
        if (!ID){
            return res.send({msg:'No User Found'})
        }
        const updateUser = await user.findByIdAndUpdate(ID,UserDetails,{new:true});
        if(!updateUser){
            return res.send({msg: "No User Found"})
        }
        console.log(updateUser)
        res.send({
            msg:"Mechanic Updated Successfully",
            data: updateUser
        })
    }
    catch(error){
        console.log("Error", error)
    }
}

const loginMechanic = async (req, res) => {
    try {
        const user1 = await user.findOne({ email: req.body.email });
        if (!user1) {
            res.send({ message: "User Not Found" });
        }

        if (req.body.password == user1.password) {
             res.send({ message: "Login Successful" });
        }
        else
        {
            res.send({ message: "Invalid Password" });
        }

       
    } catch (error) {
        res.send({ message: error.message });
    }
};


module.exports={CreateUser, getUser, deleteUser, updateUser, loginMechanic, sendEmail}