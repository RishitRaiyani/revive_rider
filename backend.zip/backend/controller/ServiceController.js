const mongoose=require('mongoose')
const Service=require('../model/servicemodel')
const CreateService = async(req,res)=>{
    const service1 = new Service({
        name: req.body.name,
        cost: req.body.cost,
        description: req.body.description,
        isAvailable: req.body.isAvailable
    })
    console.log('Service1',service1)
    service1.save()
    .then(()=>{(
        res.send({
            msg:'Data Added Successfully',
            isSuccess :true
        })
    )}
)

.catch(()=>{
    res.send({
        msg:'Error',
        isSuccess: false
    })
})
}

const getService = async(req,res)=>{
    try{
        const getService=await servicemodel.find()
        console.log(getService)
        if(getService.length==0){
            return res.send({
                msg: 'No User Found'
            })
        }
        res.send({
            msg:'User Fetch Successfully',
            data:getService
        })
    }
    catch(error){
        console.log("Error", error)
    }
}

const deleteService = async(req,res)=>{
    try{
        const ID= req.params.id;
        console.log("ID", ID)
        if (!ID){
            return res.send({msg:'No Service Found'})
        }
        const deleteService=await service.findByIdAndDelete(ID)
        if(!deleteService){
            return res.send({msg:'No Service Found'})
        }
        console.log(deleteService)
            res.send({
                msg: 'Service Deleted Successfully',
                data: deleteService
            })
        }
    catch(error){
        console.log("Error", error)
    }
}

const updateService = async(req,res)=>{
    try{
        const ID= req.params.id;
        const {name , description , cost , isAvailable }=req.body;
        const ServiceDetails ={name: name, description: description, cost: cost, isAvailable: true}
        console.log("ID", ID)
        console.log("SeviceDetails",ServiceDetails)
        if (!ID){
            return res.send({msg:'No Service Found'})
        }
        const updateService = await service.findByIdAndUpdate(ID,ServiceDetails,{new:true});
        if(!updateService){
            return res.send({msg: "No Service found"})
        }
        console.log(updateService)
        res.send({
            msg:"User Updates Successfully",
            data: updateService
        })
    }
    catch(error){
        console.log("Error", error)
    }
}

module.exports={CreateService, getService, deleteService, updateService}