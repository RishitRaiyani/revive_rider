const express=require('express')
const MechanicController=require('../controller/MechanicController')

const router=express.Router()

router.get('/getMechanic',MechanicController.getUser)

router.post('/createMechanic',MechanicController.CreateUser)

router.delete('/deleteMechanic',MechanicController.deleteUser)

router.put('/updateMechanic',MechanicController.updateUser)

router.post('/loginMechanic',MechanicController.loginMechanic)

router.post('/sendEmail',MechanicController.sendEmail)


module.exports=router