const express=require('express')
const ServiceController=require('../controller/ServiceController')

const router=express.Router()

router.get('/getService',ServiceController.getService)

router.post('/createService',ServiceController.CreateService)

router.delete('/deleteService',ServiceController.deleteService)

router.put('/updateService',ServiceController.updateService)

module.exports=router