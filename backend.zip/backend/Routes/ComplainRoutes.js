const express=require('express')
const ComplainController=require('../controller/ComplainController')

const router=express.Router()

router.get('/getComplain',ComplainController.getComplain)

router.post('/CreateComplain',ComplainController.CreateComplain)

router.delete('/deleteComplain',ComplainController.deleteComplain)

router.put('/updateComplain',ComplainController.updateComplain)

module.exports=router