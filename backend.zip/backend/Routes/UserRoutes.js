const express=require('express')
const UserController=require('../controller/UserController')

const router=express.Router()

router.get('/getUser',UserController.getUser)

router.post('/createUser',UserController.CreateUser)

router.delete('/deleteUser',UserController.deleteUser)

router.put('/updateUser',UserController.updateUser)

router.post('/login',UserController.login)

router.post('/sendEmail',UserController.sendEmail)

module.exports=router