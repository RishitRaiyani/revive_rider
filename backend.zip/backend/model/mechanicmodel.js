const mongoose = require("mongoose")
const mechanicschema = mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    },
    Number:{
        type:Number,
        required:true
    },
    emailID:{
        type:String,
        required:true
    },
})
module.exports=mongoose.model("Mechanic",mechanicschema)