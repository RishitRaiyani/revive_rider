const mongoose = require("mongoose")
const userschema = mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    age:{
        type:Number,
    },
    number:{
        type:Number,
        required: true
    },
    password:{
        type:String,
        required:true
    },
    emailID:{
        type:String,
        required:true
    },
}, {timestamps:true})
module.exports=mongoose.model("User",userschema)