const mongoose = require("mongoose")
const complainschema = mongoose.Schema({
    userID:{
        type:Number,
        required:true
    },
    serviceID:{
        type:Number,
        required: true
    },
    mechanicID:{
        type:Number,
        required:true
    },
    cost:{
        type:Number,
        required:true
    },
    isCompleted:{
    }
})
module.exports=mongoose.model("Complain",complainschema)